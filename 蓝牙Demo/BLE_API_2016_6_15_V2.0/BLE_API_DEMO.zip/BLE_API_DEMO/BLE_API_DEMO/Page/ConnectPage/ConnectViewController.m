//
//  ConnectViewController.m
//  new_HY_BLE
//
//  Created by LJ on 16/2/19.
//  Copyright © 2016年 LJ. All rights reserved.
//

#import "ConnectViewController.h"
#import "ConnectDeviceInfoCell.h"
#import "OadViewController.h"

#import "InfoViewController.h"
#import "DeviceInfoManager.h"
#import "HomePageViewController.h"
#import "BLEManager.h"

@interface ConnectViewController () <UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,BLEManagerDelegate,ConnectDeviceInfoCellDelegate> {
    NSMutableArray* _connectDeviceArray;
    NSMutableArray* _selectedDeviceArray;//保存选中的设备信息的数组
    BLEManager* _bleManager;
    NSMutableArray* _dataArray;
}
@end

@implementation ConnectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self settingView];
    //注册键盘出现的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
    //注册键盘消失的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillBeHidden:) name:UIKeyboardWillHideNotification object:nil];
    _connectDeviceArray = [[NSMutableArray alloc] init];
    _selectedDeviceArray = [[NSMutableArray alloc] init];
    _dataArray = [[NSMutableArray alloc] init];
    _bleManager = [BLEManager defaultManager];
    [self createData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    [self createData];
    _bleManager.delegate = self;
    [self showRightTabbar:self];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)createData {
    [_connectDeviceArray removeAllObjects];
    [_selectedDeviceArray removeAllObjects];
    [_dataArray removeAllObjects];
    NSMutableArray* tempArray = [[DeviceInfoManager defaultManager] findDeviceInfo];
    for (DeviceInfo* info in tempArray) {
        CBPeripheral* cb = [_bleManager getDeviceByUUID:info.UUIDString];
        if ([_bleManager readDeviceIsConnect:cb]) {
            [_connectDeviceArray addObject:info];
            [_dataArray addObject:@"no data"];
        }
    }
    [_selectedDeviceArray addObjectsFromArray:_connectDeviceArray];
    [_tableView reloadData];
}

- (void)settingView {
    self.navigationItem.title = @"new_HY_BLE";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor blueColor]}];
    _dataTextField.delegate = self;
    _sendDataButton.layer.cornerRadius = 3;
    _sendDataButton.clipsToBounds = YES;
    _sendDataButton.layer.borderWidth = 0.5;
}

- (void)keyboardWasShown:(NSNotification*)aNotification {
    //键盘高度
    CGRect keyBoardFrame = [[[aNotification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
   [UIView animateWithDuration:1.5f animations:^{
       CGRect frame = self.view.frame;
       frame.origin.y = -keyBoardFrame.size.height;
       self.view.frame = frame;
   }];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [_dataTextField resignFirstResponder];
    return YES;
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification{
    [UIView animateWithDuration:1.5f animations:^{
        CGRect frame = self.view.frame;
        frame.origin.y = 0;
        self.view.frame = frame;
    }];
}

- (IBAction)clickSendDataButton:(id)sender {
    [_dataTextField resignFirstResponder];
    [UIView animateWithDuration:1.5f animations:^{
        CGRect frame = self.view.frame;
        frame.origin.y = 0;
        self.view.frame = frame;
    }];
    NSString* string = _dataTextField.text;
    NSLog(@"%@",string);
    if (string.length == 0) {
        return;
    }
    if (string.length % 2 != 0 ) {
        string = [NSString stringWithFormat:@"%@0",string];
    }
    for (DeviceInfo* info in _selectedDeviceArray) {
        CBPeripheral* cb = [_bleManager getDeviceByUUID:info.UUIDString];
        [_bleManager sendDataToDevice1:string device:cb];
    }
    
}

#pragma mark - UITableView Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _connectDeviceArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ConnectDeviceInfoCell* cell = [tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"ConnectDeviceInfoCell" owner:self options:nil] lastObject];
    }
    cell.delegate = self;
    DeviceInfo* info = _connectDeviceArray[indexPath.row];
    if ([_selectedDeviceArray containsObject:info]) {
        cell.selectedButton.selected = YES;
    } else {
        cell.selectedButton.selected = NO;
    }
    CBPeripheral* cb = [_bleManager getDeviceByUUID:info.UUIDString];
    if ([_bleManager readDeviceIsConnect:cb]) {
        [_bleManager readDeviceRSSI:cb getRssiBlock:^(NSNumber *RSSI) {
            info.RSSI = [RSSI integerValue];
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.rssiNumberLabel.text = [NSString stringWithFormat:@"%d",[RSSI intValue]];
            });
        }];
    }
    if ([_bleManager judgeCanOADWith:cb]) {
        cell.oadButton.hidden = NO;
    } else {
        cell.oadButton.hidden = YES;
    }
    cell.index = indexPath.row;
    cell.deviceNameLabel.text = info.name;
    cell.deviceUUIDLabel.text = info.macAddrss;
    NSString* data = _dataArray[indexPath.row];
    cell.recieveDataLabel.text = data;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self hidenRightTabbar:self];
    InfoViewController* VC= [[InfoViewController alloc] initWithNibName:@"InfoViewController" bundle:nil];
    DeviceInfo* info = _connectDeviceArray[indexPath.row];
    VC.info = info;
    [self.navigationController pushViewController:VC animated:YES];
}

#pragma BleManager Delegate
- (void)receiveDeviceDataSuccess_1:(NSData *)data device:(CBPeripheral *)device {
    NSLog(@"%@",data);
    Byte* byte = (Byte*)[data bytes];
    NSString* string = @"";
    for (int i = 0; i < data.length; i++) {
        NSString* string1 = [NSString stringWithFormat:@"%X",byte[i]];
        if (string1.length == 1) {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"0%@",string1]];
        } else {
            string = [string stringByAppendingString:string1];
        }
    }
    NSLog(@"%@",string);
    for (int i = 0 ; i < _selectedDeviceArray.count; i++) {
        DeviceInfo* info = _selectedDeviceArray[i];
        if ([info.UUIDString isEqualToString:device.identifier.UUIDString]) {
            [_dataArray replaceObjectAtIndex:i withObject:string];
        }
    }
    [_tableView reloadData];
}

- (void)showRightTabbar:(UIViewController *)vc {
    UINavigationController* nc = (UINavigationController*)vc.parentViewController;
    HomePageViewController* rc = (HomePageViewController*)nc.parentViewController;
    rc.tabBar.hidden = NO;
}

- (void)hidenRightTabbar:(UIViewController*)vc {
    UINavigationController* nc = (UINavigationController*)vc.parentViewController;
    HomePageViewController* rvc = (HomePageViewController*)nc.parentViewController;
    rvc.tabBar.hidden = YES;
}

#pragma mark - ConnectDeviceInfoCellDelegate
- (void)enterOadPageWithIndex:(NSInteger)index {
    [self hidenRightTabbar:self];
    DeviceInfo* info = _connectDeviceArray[index];
    CBPeripheral* cb = [_bleManager getDeviceByUUID:info.UUIDString];
    _bleManager.oadPeripheral = cb;
    
    OadViewController* vc = [[OadViewController alloc] initWithNibName:@"OadViewController" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

@end

